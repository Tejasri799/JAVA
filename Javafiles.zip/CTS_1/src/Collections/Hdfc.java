package Collections;

public class Hdfc extends Bank {
	@Override
	float get_roi(){
	return 6.5f;
	}
}

