package Collections;

public class Test_Interference {
	public static void main(String[] args) {
		drawable d= new Rectangle();
		d.draw();
	}

}
