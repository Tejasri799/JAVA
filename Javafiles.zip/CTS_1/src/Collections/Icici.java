package Collections;

public class Icici extends Bank{
	@Override
	float get_roi(){
	return 8.5f;
	}
}
