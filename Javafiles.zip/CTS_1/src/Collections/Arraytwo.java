package Collections;

import java.util.ArrayList;

public class Arraytwo {
ArrayList<student> std_al = new ArrayList<student>();
public void create_al()
{
	student s1 = new student("Shivika",101,86,96);
	student s2 = new student("Rikara",102,78,92);
	std_al.add(s1);
	std_al.add(s2);
}

public void display_al()
{
	for(student s : std_al)
	{
		System.out.println(" Name : " + s.name
				+" ID : " + s.id
				+"Selenium Marks : " + s.selenium
				+" JAVA marks : " + s.java
				+" Avg : " + s.avg );
	}
}
public static void main(String[] args) {
	Arraytwo p = new Arraytwo();
	p.create_al();
	p.display_al();
}
}
