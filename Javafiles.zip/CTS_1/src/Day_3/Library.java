package Day_3;

public class Library {
	public int add(int x,int y){
		int c=x+y;
		return c;
	}

}
