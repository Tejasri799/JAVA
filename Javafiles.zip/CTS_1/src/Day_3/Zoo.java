package Day_3;

public class Zoo {
	public static void main(String[] args) {
		Elephant ep= new Elephant();
		ep.age=6;
		ep.weight=230;
		ep.height=9;
		ep.color="Grey";
		ep.c='m';
		ep.lotrunk=1;
		ep.lotusk=2;
		ep.display_details();
	}

}
