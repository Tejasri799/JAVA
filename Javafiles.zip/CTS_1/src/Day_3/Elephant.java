package Day_3;

public class Elephant extends Animal{
	int lotrunk, lotusk;

	public void display_details()
	{
		super.display();
		System.out.println("lotrunk : " + lotrunk + " + lotusk");
		// TODO Auto-generated method stub

	}

}
