package Day_4;

public class Employee_search {

	 String str[][]={{"11", "Ankia"},{"12", "Shivaay"},{"13", "Omkara"},{"14", "Teju"},{"15", "Rudra"}};
	 int marks[][]={{11,94,96,0},{12,49,40,0},{13,58,44,0},{14,88,96,0},{15,67,96,0}};

	 public  int search (String sid)
{
		 int index=0,i;
		 int id=Integer.parseInt(sid);
		 for(i=0;i<=4;i++)
		 {
			 if(id==marks[i][0])
			 	{
				 	index=i;
				 	break;
			 	}
		 }

		 return index;
}
	 public  int calc_avg(int ind)
{
		 int avg;
		 avg=(marks[ind][1]+marks[ind][2])/2;
		 return avg;
}
	 public  String get_name(String stdid)
{
		 String n=null;
		 for(int j=0;j<=4;j++)
		 {
			 if(stdid.equals(str[j][0]))
			 {
				 n=str[j][1];
				 break;
			 }
		 }
		 return n;
}

	 public static void main(String[] args)
	 {
		 SearchArray q = new SearchArray();

		 int i=q.search("13");
		 int average=q.calc_avg(i);
		 String name=q.get_name("13");
		 System.out.println("Name : " +name + " Average : " +average);
	}

}
