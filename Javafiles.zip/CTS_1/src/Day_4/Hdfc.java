package Day_4;

public class Hdfc extends Bank {
	public float get_Roi(){
		return 7.5f;
	}


}
