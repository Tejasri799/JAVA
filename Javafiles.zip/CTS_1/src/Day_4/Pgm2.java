package Day_4;

import java.util.Scanner;

public class Pgm2 {
	public static void main(String[] args) {
		System.out.println("Enter the employee id : ");
		Scanner s = new Scanner(System.in);
		String str = s.next();
		String [][]emp = {{"e1", "Anika"}, {"e2", "Shivaay"},{"e3", "Teju"},{"e4", "Omkara"},{"e5", "Rudra"}};
		for(int i=0; i<emp.length; i++)
		{
			int j=0;
			int c = str.compareTo(emp[i][j]);
			if(c==0)
				System.out.println(emp[i][j+1]);
		}
		
	}

}
