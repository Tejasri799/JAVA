package Day_1;
import java.util.Scanner;
public class Pgm5 {
	public static void main(String[] args) {
	Scanner s1=new Scanner (System.in);
	System.out.println("Enter salary");
	long x= s1.nextLong();
	int a=0;
	if(x>0 && x<=180000)
	{
		System.out.println(a);
		
	}
	else if(x>180000 && x<= 500000)
	{
		long f=(x-180000);
		double k=(f*0.1);
		System.out.println(k);
	}
	else if (x>500000 && x<=800000){
		float p=(x-500000);
		double q=(p*0.2);
	}
	else if(x>800000){
		float s=(x-800000);
		double t= (s*0.3);
	}
	}

}
