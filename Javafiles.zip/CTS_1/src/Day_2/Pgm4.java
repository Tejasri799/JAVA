package Day_2;

public class Pgm4 {
	public static void main(String[] args) {
		String s = "Chennai",s1 = "Chennai",s2 = "Chennai",s3;
		int l=s.length();
		int v = s.compareTo(s2);
		System.out.println("Length = " + 1 + "Return Value : " + v);
		 int rv = s.compareToIgnoreCase(s2);
		 System.out.println("rv=");
		s3=s.substring(0,4);
		System.out.println("Substring : " + s3);
		int p = s.indexOf("n",0);
		System.out.println("Position :" + p);
		int p1 = s.indexOf("n",p+1);
		System.out.println("Position of 2nd n :" + p1);
	}

}
