package Day_2;

public class Pgm6{
	public static void main(String[] args) {
		String s="I am learning core java";
		int c=0,p,i=0,p1=0;
		while(p1>=0)
		{
			p1=s.indexOf(" ",i);
			c++;
			p=p1;
			if(p==-1)
			{
				p=s.length();
			}
			System.out.println("i = " + i + "p= " + p);
			String sub = s.substring(i,p);
			i=p+1;
			System.out.println(sub);
		}
		System.out.println("Number of words = " + c);
		
	}

}
