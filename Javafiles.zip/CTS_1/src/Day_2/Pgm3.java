package Day_2;
import java.io.*;
public class Pgm3 {
	public static void main(String[] args) {
		int arr[][]={{25,48,12},{81,42,16},{48,60,23},{54,22,51}};
		int sum=0;
	for(int i=0; i<4; i++)
	{
		for(int j=0; j<3; j++)
		{
			if(arr[i][j]%2==0)
				sum=sum+arr[i][j];
		}
	}
	System.out.println("sum of even numbers " +sum);
	}
}
