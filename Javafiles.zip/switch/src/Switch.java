import java.util.Scanner;
public class Switch {
	void Marker(){
		char color;
		Scanner sc= new Scanner(System.in);
		color=sc.next().charAt(0);
		switch(color)
		{
	
		case 'G':
			System.out.println("color is green");
			break;
		case 'B':
			System.out.println("color is black");
			break;
		case 'b':
			System.out.println("Color is Blue");
			break;
		case 'p':
			System.out.println("color is pink");
			break;
			default:
				System.out.println("Highlighter");
		}
		
	}
public static void main(String[] args) {
	Switch j1 = new Switch();
	j1.Marker();
	
}
}
