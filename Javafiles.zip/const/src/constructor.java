
public class constructor {
	constructor() {
		System.out.println("brand is MONTEX");
	}
	constructor(int length, String color){
		System.out.println("length in cm is"+length+" "+color);
	}
	
	
	public static void main(String[]args){
		constructor object1 = new constructor(6, "color is red");
		constructor object2 = new constructor();
		
	}
	

}
