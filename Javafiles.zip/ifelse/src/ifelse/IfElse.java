                                                                                                                                                                                                                                                                                                                                                           package ifelse;
import java.util.Scanner;
public class IfElse {
	void hall(){
		Scanner s = new Scanner(System.in);
		System.out.println("enter age");
		int age=s.nextInt();
			if(age>=10&&age<=50) {
				System.out.println("permission granted");
			}
			else
				if(age>=50)
					System.out.println("better luck next life");
	}
	public static void main(String[] args) {
		IfElse t1=new IfElse();
		t1.hall();
	}
}
	
	


