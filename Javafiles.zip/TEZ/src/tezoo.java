
public class tezoo {
	tezoo(){
		System.out.println("Hello Tezoooooooooooooooo");
	}
	public static void main(String[] args) {
	System.out.println("Tejasri");
	tezoo t1 = new tezoo();
	}

}
